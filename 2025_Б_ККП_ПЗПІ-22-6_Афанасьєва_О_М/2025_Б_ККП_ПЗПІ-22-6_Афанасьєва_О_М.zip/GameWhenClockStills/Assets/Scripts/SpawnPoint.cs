using UnityEngine;

public class SpawnPoint : MonoBehaviour
{
    public string fromLocation;
    public bool flipPlayer = false;
}